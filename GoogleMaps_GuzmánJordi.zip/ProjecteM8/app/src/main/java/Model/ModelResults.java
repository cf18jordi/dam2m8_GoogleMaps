package Model;

public class ModelResults {

        public String sunrise;
        public String sunset;

}



