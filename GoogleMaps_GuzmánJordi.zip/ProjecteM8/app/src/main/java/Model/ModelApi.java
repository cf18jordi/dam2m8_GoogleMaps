package Model;

public class ModelApi {

        public String status;
        public ModelResults results;


}
